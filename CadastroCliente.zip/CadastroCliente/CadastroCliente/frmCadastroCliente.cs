﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Utilitarios;

namespace CadastroCliente
{
    public partial class frmCadastroCliente : Form
    {
        public frmCadastroCliente()
        {
            InitializeComponent();
        }

        private void frmCadastroCliente_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            bool cpf = Utilitarios.MetodosExtensao.ValidarCPF(txtCPF.Text);
            if (cpf)
            {
                MessageBox.Show("Valido");

            }
            else
            {
            MessageBox.Show("Não Valido");

            }

        }
    }
}
